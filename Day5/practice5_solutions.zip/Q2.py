# # 2. Intermediate Steps of Selection Sort
# Write function `print_selection` that prints list immediate result at Kth iteration during selection sort.

# If `K` is larger than length of list, function prints -1
   

def print_selection(arr, K):
    n = len(arr)

    # If K is larger than the length of the list
    if K > n:
        print(-1)
        return

    for i in range(n):
        min_idx = i
        for j in range(i + 1, n):
            if arr[j] < arr[min_idx]:
                min_idx = j

        # Swap the found minimum element with the first element
        arr[i], arr[min_idx] = arr[min_idx], arr[i]

        # Print the list at the Kth iteration
        if i == K - 1:
            print(arr)
            return