# 5. Sort Characters By Frequency
# Given a string `s`, write a function `frequencySort(s)` that sort it in decreasing order based on the frequency of the characters. The frequency of a character is the number of times it appears in the string.

# ### Requirements

# *   Return the sorted string. If there are multiple answers, return any of them.
# *   `s` consists of uppercase and lowercase English letters and digits.
# *   Do not import any other module.(ex. `collections`, `itertools`)
# *   Do not use built-in functions (ex. `sorted`, etc.)




def frequencySort(s):
    # Create a dictionary to count character frequencies
    freq = {}
    for char in s:
        if char in freq:
            freq[char] += 1
        else:
            freq[char] = 1

    # Convert the frequency dictionary into a list of tuples and sort it
    # 1. Primary sort key: frequency (descending order)
    # 2. Secondary sort key: lexicographical order (ascending)
    freq_items = list(freq.items())
    for i in range(len(freq_items)):
        for j in range(i + 1, len(freq_items)):
            # Custom sorting logic
            if (freq_items[i][1] < freq_items[j][1]) or (freq_items[i][1] == freq_items[j][1] and freq_items[i][0] > freq_items[j][0]):
                freq_items[i], freq_items[j] = freq_items[j], freq_items[i]

    # Build the result string based on the sorted list
    result = ""
    for char, count in freq_items:
        result += char * count

    return result