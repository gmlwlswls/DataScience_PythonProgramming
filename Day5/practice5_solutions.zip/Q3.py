# # 3. String List Sorting with Insertion Sorting

# Write a function `sort_strings(lst)` to sort a list of strings based on the following criteria using the insertion sort algorithm:

# ### Requirements
# 1. Strings with shorter lengths should come first.
# 2. If strings have the same length, they should be sorted in lexicographical order.
# 3. Do not use built-in sorting functions; instead, implement the insertion sort algorithm.


def sort_strings(lst):
    def compare(s1, s2):
        if len(s1) != len(s2):
            return len(s1) - len(s2)
        else:
            if s1 < s2:
                return -1
            elif s1 > s2:
                return 1
            else:
                return 0

    def insertion_sort(arr):
        for i in range(1, len(arr)):
            key = arr[i]
            j = i - 1
            while j >= 0 and compare(arr[j], key) > 0:
                arr[j + 1] = arr[j]
                j -= 1
            arr[j + 1] = key
        return arr

    return insertion_sort(lst)